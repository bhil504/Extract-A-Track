package com.BhillionDollarApps.extrack_a_track.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

@Configuration
public class S3ClientInitializer {

    @Bean
    public S3Client s3Client() {
        // Initialize S3Client using AWS SDK v2
        return S3Client.builder()
                .region(Region.US_EAST_1)  // Replace with your region
                .build();
    }
}
