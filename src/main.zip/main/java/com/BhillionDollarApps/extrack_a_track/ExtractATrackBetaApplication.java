package com.BhillionDollarApps.extrack_a_track;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExtractATrackBetaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExtractATrackBetaApplication.class, args);
	}

}
